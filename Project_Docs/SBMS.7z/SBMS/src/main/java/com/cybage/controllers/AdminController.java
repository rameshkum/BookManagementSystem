package com.cybage.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.dto.BooksDTO;
import com.cybage.dto.UsersDTO;
import com.cybage.entity.Books;
import com.cybage.entity.Reviews;
import com.cybage.services.BooksServiceInterface;
import com.cybage.services.UsersServiceInterface;

@Controller
@RequestMapping(value="/admin")
public class AdminController 
{
	@Autowired
	UsersServiceInterface userservice;
	@Autowired
	BooksServiceInterface bookservice;
	/*BooksDTO booksdto;
	AdminController()
	{
		booksdto=new BooksDTO();
	}*/
	@RequestMapping(value="/blank")
	public @ResponseBody ModelAndView AdminBlank()
	{
		return new ModelAndView("Blank");
	}
	@RequestMapping(value="/menu", method=RequestMethod.GET)
	public @ResponseBody ModelAndView AdminOptions()
	{
		return new ModelAndView("AdminOptions");
	}
	@RequestMapping(value="/addbookpage", method=RequestMethod.GET)
	public @ResponseBody ModelAndView addBookPage()
	{
		return new ModelAndView("AddBook");
	}
	@RequestMapping(method=RequestMethod.POST)
	public @ResponseBody ModelAndView adminPage(UsersDTO user)
	{
		System.out.println(user.getEmail());
		return new ModelAndView("admin","userdto", user);
	}
	@RequestMapping(value="/booklist", method=RequestMethod.GET)
	public @ResponseBody ModelAndView bookList()
	{
		List<Books> list=bookservice.getBookList();
		for(Books i : list)
		{
			System.out.println(i.getBid()+i.getAuthor());
		}
		/*return list;*/
		return new ModelAndView("BookList", "list", list);
	}
	@RequestMapping(value="/addbook", method=RequestMethod.POST)
	public @ResponseBody boolean addBook(HttpServletRequest request, BooksDTO booksdto)
	{
		System.out.println(booksdto.getBname());
		Boolean b=bookservice.addBook(booksdto);
		if(b)
		{
			System.out.println("Success");
			return true;
		}
		else
		{
			System.out.println("Conflict");
			return false;
		}
	}
	@RequestMapping(value="/editbook/{id}", method=RequestMethod.GET)
	public @ResponseBody ModelAndView editBook(HttpServletRequest request, @PathVariable int id)
	{
		System.out.println(id);
		Books book=bookservice.searchBook(id);
		System.out.println(book.getBname());
		return new ModelAndView("EditBook", "book", book);
	}
	@RequestMapping(value="/editbookpage", method=RequestMethod.POST)
	public @ResponseBody ModelAndView editBookPage(BooksDTO book)
	{
		System.out.println("inside edit book page");
		return new ModelAndView("EditBook", "book", book);
	}
	@RequestMapping(value="/updatebook", method=RequestMethod.POST)
	public @ResponseBody boolean updateBook(BooksDTO booksdto)
	{
	    System.out.println(booksdto.getBid());
		boolean b=bookservice.updateBook(booksdto);
		System.out.println(b);
		return b;
	}
	@RequestMapping(value="/deletebook/{id}", method=RequestMethod.GET)
	public @ResponseBody ModelAndView deleteBook(@PathVariable int id)
	{
		bookservice.deleteBook(id);
		List<Books> list=bookservice.getBookList();
		return new ModelAndView("BookList", "list", list);
		
	}
	@RequestMapping(value="/viewreviews", method=RequestMethod.GET)
	public @ResponseBody ModelAndView viewReviews()
	{
		List<Reviews> reviews=bookservice.getReviewsList();
		return new ModelAndView("AdminViewReviews", "reviews", reviews);
	}
	@RequestMapping(value="/deletereview/{id}", method=RequestMethod.GET)
	public @ResponseBody ModelAndView deleteReview(@PathVariable int id)
	{
		List<Reviews> reviews=bookservice.deleteReview(id);
		return new ModelAndView("AdminViewReviews", "reviews", reviews);
	}
}
