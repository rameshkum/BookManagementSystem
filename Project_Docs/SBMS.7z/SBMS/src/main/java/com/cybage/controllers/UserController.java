package com.cybage.controllers;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.dto.ReviewsDTO;
import com.cybage.dto.UsersDTO;
import com.cybage.entity.Books;
import com.cybage.entity.Reviews;
import com.cybage.entity.Users;
import com.cybage.services.BooksService;
import com.cybage.services.BooksServiceInterface;
import com.cybage.services.UsersService;
import com.cybage.services.UsersServiceInterface;

@Controller
@RequestMapping("/user")
public class UserController
{
	@Autowired 
	UsersServiceInterface userservice;
	@Autowired
	BooksServiceInterface bookservice;
	@RequestMapping(method=RequestMethod.POST)
	public @ResponseBody ModelAndView userPage(UsersDTO user)
	{
		System.out.println(user.getEmail());
		return new ModelAndView("user", "userdto", user);
	}
	@RequestMapping(value="/blank")
	public @ResponseBody ModelAndView AdminBlank()
	{
		return new ModelAndView("Blank");
	}
	@RequestMapping(value="/menu", method=RequestMethod.GET)
	public @ResponseBody ModelAndView AdminOptions()
	{
		return new ModelAndView("UserOptions");
	}
	@RequestMapping(value="/booklist", method=RequestMethod.GET)
	public @ResponseBody ModelAndView bookList()
	{
		List<Books> list=bookservice.getBookList();
		for(Books i : list)
		{
			System.out.println(i.getBid()+i.getAuthor());
		}
		return new ModelAndView("UserBookList", "list", list);
	}
	@RequestMapping(value="/addreview/{id}", method=RequestMethod.GET)
	public @ResponseBody ModelAndView addReviewPage(@PathVariable int id, HttpSession session, Map<String, Object> model)
	{
		Books book=bookservice.findBookById(id);
		System.out.println(book.getBname());
		int uid=(Integer) session.getAttribute("id");
		Users user=userservice.findUserById(uid);
		System.out.println(user.getUid());
		model.put("user", user);
		return new ModelAndView("AddReviewPage","book", book);
	}
	@RequestMapping(value="/addreview", method=RequestMethod.POST)
	public @ResponseBody ModelAndView addReview(HttpServletRequest request)
	{
		Reviews reviews=new Reviews();
		System.out.println(request.getParameter("bid"));
		reviews.setComments(request.getParameter("comments"));
		reviews.setDate(request.getParameter("date"));
		reviews.setBooks(bookservice.findBookById(Integer.parseInt(request.getParameter("bid"))));
		reviews.setUsers(userservice.findUserById(Integer.parseInt(request.getParameter("uid"))));
		reviews.setRating(Integer.parseInt(request.getParameter("rating")));
		boolean review=bookservice.addReview(reviews);
		return new ModelAndView("Blank", "review", review);
	}
	@RequestMapping(value="/viewreviews/{id}", method=RequestMethod.GET)
	public @ResponseBody ModelAndView viewReviews(@PathVariable int id)
	{
		List<Reviews> reviews=bookservice.viewReviews(id);
		System.out.println("After DB Activity of reviews");
		for(Reviews r: reviews)
		{
			System.out.println(r.getComments()+" "+r.getBooks().getBname());
		}
		return new ModelAndView("ViewReviews", "reviews", reviews);
	}
}
