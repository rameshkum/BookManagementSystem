package com.cybage.controllers;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.dto.UsersDTO;
import com.cybage.entity.Users;
import com.cybage.services.UsersService;
import com.cybage.services.UsersServiceInterface;

@Controller
@RequestMapping(value="/")
public class UsersController
{
	@Autowired
	UsersServiceInterface userservice;
	UsersDTO userdto;
	UsersController()
	{
		userdto=new UsersDTO();
	}
	@RequestMapping(value="header", method=RequestMethod.GET)
	public @ResponseBody ModelAndView HeaderPage()
	{
		return new ModelAndView("Header");
	}
	@RequestMapping(value="validatelogin", method=RequestMethod.POST)
	public @ResponseBody Users validate(HttpServletRequest request, HttpServletResponse response, Map<String, Object> model) throws IOException
	{
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		HttpSession session=request.getSession(true);
		session.setAttribute("SessionId", session.getId());
		
		userdto.setEmail(email);
		userdto.setPassword(password);
		System.out.println(userdto.getEmail()+" "+userdto.getPassword());
		List<Users> user=userservice.validateUser(userdto);
		session.setAttribute("id", user.get(0).getUid());
		session.setAttribute("user",user.get(0).getFname()+" "+user.get(0).getLname() );
		if(!user.isEmpty())
		{
			/*session.setAttribute("user",user.get(0).getFname()+" "+user.get(0).getLname() );
			session.setAttribute("id", user.get(0).getUid());
			return userservice.getViewPage(user.get(0), email,password);*/
			/*if(user.get(0).getEmail().equals(email))
			{
				*//*if(user.get(0).getPassword().equals(password))
				{
					session.setAttribute("user",user.get(0).getFname()+" "+user.get(0).getLname() );
					session.setAttribute("id", user.get(0).getUid());
					System.out.println(user.get(0).getFname());
					if(user.get(0).getRole().equals("admin"))
					{
						System.out.println("Inside Admin");
						return new ModelAndView("admin","user", user.get(0));
					}
					else
					{
						System.out.println("Inside User");
						return new ModelAndView("user", "user", user.get(0));
					}
				}
				else
				{
					model.put("msg", "Invalid password");
					return new ModelAndView("index");
				}*/
				/*}
			else
			{
				model.put("msg", "User does not exist....! Please Register");
				return new ModelAndView("index");
			}*/
			return user.get(0);
		}
		else
		{
			return null;
			/*model.put("msg", "Invalid Credentials");
			System.out.println("object is empty");
			return new ModelAndView("index");*/
		}
	}
	@RequestMapping(value="register", method=RequestMethod.GET)
	public @ResponseBody ModelAndView registerPage()
	{
		return new ModelAndView("registeruser");
	}
	@RequestMapping(value="registeruser", method=RequestMethod.POST)
	public @ResponseBody boolean registerUser(HttpServletRequest request, UsersDTO userdto) 
	{
		System.out.println(userdto.getEmail());
		Boolean b=userservice.addUser(userdto);
		if(b)
		{
			System.out.println("Success");
			return true;
		}
		else
		{
			System.out.println("Conflict");
			return false;
		}
	}
	@RequestMapping(value={"","logout"})
	public @ResponseBody ModelAndView logout(HttpSession session)
	{
		session.invalidate();
		return new ModelAndView("index");
	}
}
