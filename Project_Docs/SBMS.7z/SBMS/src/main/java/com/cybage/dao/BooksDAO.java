package com.cybage.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.SharedSessionContract;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.dto.BooksDTO;
import com.cybage.dto.UsersDTO;
import com.cybage.entity.Books;
import com.cybage.entity.Reviews;
import com.cybage.entity.Users;
@Repository
public class BooksDAO implements BooksDAOInterface
{
	@Autowired
	SessionFactory sessionfactory;
	Books book;
	BooksDAO()
	{
		book=new Books();
	}
	@Transactional(value="hibernateTransactionManager")
	public List<Books> getBookList()
	{
		List<Books> list=(List<Books>) sessionfactory.getCurrentSession().createCriteria(Books.class).list();
		return list;
	}
	@Transactional(value="hibernateTransactionManager")
	public boolean addBook(BooksDTO booksdto) 
	{ 
		List<Books> list=searchBook(booksdto);
		if(list.isEmpty())
		{
			System.out.println(booksdto.getBname());
			book.setBname(booksdto.getBname());
			book.setAuthor(booksdto.getAuthor());
			book.setDescription(booksdto.getDescription());
			book.setPrice(booksdto.getPrice());
			sessionfactory.getCurrentSession().save(book);
			return true;
		}
		else
		{
			return false;
		}
	}
	@Transactional(value="hibernateTransactionManager")
	public List<Books> searchBook(BooksDTO booksdto)
	{
		String bname=booksdto.getBname();
		String author=booksdto.getAuthor();
		Query query = sessionfactory.getCurrentSession().createQuery("from Books where bname=:bname and author=:author");
	  	query.setParameter("bname",bname);
	  	query.setParameter("author", author);
	  	List<Books> list=(List<Books>)query.list();
	  	return list;
	}
	@Transactional(value="hibernateTransactionManager")
	public Books findBookById(int bid) 
	{
		Books book=(Books) sessionfactory.getCurrentSession().get(Books.class,bid);
		return book;
	}
	@Transactional(value="hibernateTransactionManager")
	public boolean updateBook(BooksDTO booksdto) 
	{
		System.out.println(booksdto.getBname());
		book.setBid(booksdto.getBid());
		book.setAuthor(booksdto.getAuthor());
		book.setBname(booksdto.getBname());
		book.setDescription(booksdto.getDescription());
		book.setPrice(booksdto.getPrice());
		if(book.getBid()>0)
		{
			sessionfactory.getCurrentSession().saveOrUpdate(book);
			return true;
		}
		else
		
			return false;
	}
	@Transactional(value="hibernateTransactionManager")
	public boolean deleteBook(int id) 
	{
		Books book=findBookById(id);
		sessionfactory.getCurrentSession().delete(book);
		return true;
	}
	@Transactional(value="hibernateTransactionManager")
	public List<Reviews> viewReviews(int bid) 
	{
		Query query = sessionfactory.getCurrentSession().createQuery("from Reviews where bid=:bid");
		query.setParameter("bid",bid);
		List<Reviews> list=(List<Reviews>)query.list();
		return list;
	}
	@Transactional(value="hibernateTransactionManager")
	public List<Reviews> getReviewsList() 
	{
		List<Reviews> reviews=sessionfactory.getCurrentSession().createCriteria(Reviews.class).list();
		return reviews;
	}
	@Transactional(value="hibernateTransactionManager")
	public List<Reviews> deleteReview(int id) 
	{

		Reviews review=findReviewById(id);
		sessionfactory.getCurrentSession().delete(review);
		List<Reviews> list=getReviewsList();
		return list;
	}
	@Transactional(value="hibernateTransactionManager")
	public Reviews findReviewById(int id)
	{
		Reviews review=(Reviews) sessionfactory.getCurrentSession().get(Reviews.class,id);
		return review;
	}
	@Transactional(value="hibernateTransactionManager")
	public boolean addReview(Reviews reviews)
	{
		Serializable s=sessionfactory.getCurrentSession().save(reviews);
		System.out.println(s);
		if(s!=null)
		{
			return true;
		}
		else 
			return false;
	}
}
