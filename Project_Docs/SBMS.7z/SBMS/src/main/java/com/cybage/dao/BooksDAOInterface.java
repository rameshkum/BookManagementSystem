package com.cybage.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cybage.dto.BooksDTO;
import com.cybage.entity.Books;
import com.cybage.entity.Reviews;
@Component
public interface BooksDAOInterface
{
	public  List<Books> getBookList();
	public boolean addBook(BooksDTO booksdto);
	public List<Books> searchBook(BooksDTO booksdto);
	public Books findBookById(int bid);
	public boolean updateBook(BooksDTO booksdto);
	public boolean deleteBook(int id);
	public List<Reviews> viewReviews(int bid);
	public List<Reviews> getReviewsList();
	public List<Reviews> deleteReview(int id);
	public Reviews findReviewById(int id);
	public boolean addReview(Reviews reviews);
}
