package com.cybage.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.dto.UsersDTO;
import com.cybage.entity.Books;
import com.cybage.entity.Users;
@Repository
public class UsersDAO implements UsersDAOInterface
{
	@Autowired
	SessionFactory sessionfactory;
	Users user;
	UsersDAO()
	{
		user=new Users();
	}
	@Transactional(value="hibernateTransactionManager")
	public List<Users> validateUser(UsersDTO userdto) 
	{
	  	List<Users> list=searchUser(userdto);
	  	return list;
	}
	@Transactional(value="hibernateTransactionManager")
	public Boolean addUser(UsersDTO userdto)
	{
		List<Users> list=searchUser(userdto);
		if(list.isEmpty())
		{
			System.out.println(userdto.getEmail());
			user.setEmail(userdto.getEmail());
			user.setFname(userdto.getFname());
			user.setPassword(userdto.getPassword());
			user.setRole(userdto.getRole());
			user.setLname(userdto.getLname());
			sessionfactory.getCurrentSession().save(user);
			return true;
		}
		else
		{
			return false;
		}
	}
	public List<Users> searchUser(UsersDTO userdto)
	{
		String email=userdto.getEmail();
		Query query = sessionfactory.getCurrentSession().createQuery("from Users where email=:email");
	  	query.setParameter("email",email);
	  	List<Users> list=(List<Users>)query.list();
	  	return list;
	}
	@Transactional(value="hibernateTransactionManager")
	public Users findUserById(int uid)
	{
		Users book=(Users) sessionfactory.getCurrentSession().get(Users.class,uid);
		return book;
	}
	
}
