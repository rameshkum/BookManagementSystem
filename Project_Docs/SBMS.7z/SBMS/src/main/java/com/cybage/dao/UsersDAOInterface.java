package com.cybage.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cybage.dto.UsersDTO;
import com.cybage.entity.Users;

@Component
public interface UsersDAOInterface
{
	public List<Users> validateUser(UsersDTO userdto);
	public Boolean addUser(UsersDTO userdto);
	public List<Users> searchUser(UsersDTO userdto);
	public Users findUserById(int uid);
}
