package com.cybage.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Table(name="reviews")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Reviews 
{
	@Id
	@GeneratedValue
	@Column(name="rid")
	private int rid;
	@Column(name="comments")
	private String comments;
	@Column(name="rating")
	private int rating;
	@Column(name="date")
	private String date;
	/*@Column(name="books_bid")*/
	/*private int bid;*/
	/*@Column(name="users_uid", nullable=false)*/
	/*private int uid;*/
	@ManyToOne
	@JoinColumn(name = "bid")
	private Books books;
	
	@ManyToOne
	@JoinColumn(name = "uid")
	private Users users;
	
	/*public Books getBook() {
		return books;
	}
	public void setBook(Books books) {
		this.books = books;
	}*/
	public int getRid() 
	{
		return rid;
	}
	public void setRid(int rid) 
	{
		this.rid = rid;
	}
	public String getComments() 
	{
		return comments;
	}
	public void setComments(String comments) 
	{
		this.comments = comments;
	}
	public int getRating() 
	{
		return rating;
	}
	public void setRating(int rating) 
	{
		this.rating = rating;
	}
	public String getDate() 
	{
		return date;
	}
	public void setDate(String date) 
	{
		this.date=date;
	}

	/*public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}*/
	public Books getBooks() {
		return books;
	}
	public void setBooks(Books books) {
		this.books = books;
	}
	public Users getUsers() {
		return users;
	}
	public void setUsers(Users users) {
		this.users = users;
	}


}
