package com.cybage.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.dao.BooksDAO;
import com.cybage.dao.BooksDAOInterface;
import com.cybage.dto.BooksDTO;
import com.cybage.dto.ReviewsDTO;
import com.cybage.entity.Books;
import com.cybage.entity.Reviews;
@Service
public class BooksService implements BooksServiceInterface
{
	@Autowired
	BooksDAOInterface booksdao;
	public List<Books> getBookList() 
	{
		return booksdao.getBookList();
	}
	public Boolean addBook(BooksDTO booksdto) 
	{
		boolean u=booksdao.addBook(booksdto);
		return u;
	}
	public Books searchBook(int bid)
	{
		Books book=booksdao.findBookById(bid);
		return book;
	}
	public boolean updateBook(BooksDTO booksdto) 
	{
		boolean b=booksdao.updateBook(booksdto);
		System.out.println(b);
		return b;
	}
	public boolean deleteBook(int id) 
	{
		return booksdao.deleteBook(id);
		
	}
	public Books findBookById(int id) 
	{
		Books b=booksdao.findBookById(id);
		return b;
	}
	public boolean addReview(Reviews reviews) 
	{
		boolean review=booksdao.addReview(reviews);
		return review;
	}
	public List<Reviews> viewReviews(int bid) 
	{
		List<Reviews> reviews=booksdao.viewReviews(bid);
		return reviews;
	}
	public List<Reviews> getReviewsList() 
	{
		List<Reviews> reviews=booksdao.getReviewsList();
		return reviews;
	}
	public List<Reviews> deleteReview(int id)
	{
		List<Reviews> list=booksdao.deleteReview(id);
		return list;
	}
	
}
