package com.cybage.services;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cybage.dto.BooksDTO;
import com.cybage.entity.Books;
import com.cybage.entity.Reviews;
@Component
public interface BooksServiceInterface 
{
	public List<Books> getBookList();
	public Boolean addBook(BooksDTO booksdto);
	public Books searchBook(int bid);
	public boolean updateBook(BooksDTO booksdto);
	public boolean deleteBook(int id);
	public Books findBookById(int id);
	public boolean addReview(Reviews reviews);
	public List<Reviews> viewReviews(int bid);
	public List<Reviews> getReviewsList();
	public List<Reviews> deleteReview(int id);
}
