package com.cybage.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.dao.UsersDAO;
import com.cybage.dao.UsersDAOInterface;
import com.cybage.dto.ReviewsDTO;
import com.cybage.dto.UsersDTO;
import com.cybage.entity.Books;
import com.cybage.entity.Reviews;
import com.cybage.entity.Users;
@Service
public class UsersService implements UsersServiceInterface
{
	@Autowired
	UsersDAOInterface userdao;

	public List<Users> validateUser(UsersDTO userdto) {
		List<Users> user=userdao.validateUser(userdto);
		
		return user;
	}

	public boolean addUser(UsersDTO userdto) 
	{
		boolean u=userdao.addUser(userdto);
		return u;
	}

	public Users findUserById(int uid) 
	{
		Users user=userdao.findUserById(uid);
		return user;
	}
	/*public ModelAndView getViewPage(Users user,String email, String password)
	{
			if(user.getPassword().equals(password))
			{
				
				System.out.println(user.getFname());
				if(user.getRole().equals("admin"))
				{
					return new ModelAndView("admin");
				}
				else
				{
					return new ModelAndView("user");
				}
			}
			else
			{
				return new ModelAndView("index");
			}
	}*/

}
