package com.cybage.services;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.dto.UsersDTO;
import com.cybage.entity.Users;
@Component
public interface UsersServiceInterface 
{
	public List<Users> validateUser(UsersDTO userdto);
	public boolean addUser(UsersDTO userdto);
	public Users findUserById(int uid);
	/*public ModelAndView getViewPage(Users user,String email, String password);*/
}
