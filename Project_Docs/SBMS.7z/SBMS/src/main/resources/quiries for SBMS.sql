create database sbmsdb;
use sbmsdb;
drop table if exists users;
create table users(uid integer auto_increment not null, fname varchar(50) not null, lname varchar(50) not null, email varchar(100) unique not null, password varchar(50) not null, role varchar(20) not null, primary key(uid));
drop table if exists books;
create table books(bid integer auto_increment, bname varchar(100) not null, author varchar(100) not null, price decimal(9,3) not null, description varchar(300) not null, primary key (bid));
CREATE TABLE reviews(rid integer auto_increment not null, bid integer,uid integer, comments varchar(300) not null, rating integer, date DATETIME not null,  primary key (rid), foreign key fk1 (bid) references books(bid), foreign key fk2 (uid) references users(uid));
drop table if exists reviews;
desc reviews;
insert into users(fname, lname, email, password, role) values("sandhya", "kotturi", "sandhyakot@cybage.com", "abc", "admin");
select * from users;
show databases;
use example;
select * from user;
insert into books(bname, author, price, description) values("The Waste Land", "T. S. Eliot", 51.15,"The Waste Land is a metaphor for the state of the world as Eliot saw it");
select * from books;
insert into reviews(bid, uid, comments, rating, date) values(2, 2,"good one", 5, '2017-05-12 17:51:50');
select * from reviews;
drop table reviews;
CREATE TABLE  REGISTERUSER   
   (    NAME VARCHAR(4000),   
    PASS VARCHAR(4000),   
    EMAIL VARCHAR(4000),   
    COUNTRY VARCHAR(4000)  
   ) ;
use example;
select * from emp1000;
desc emp1000;

select * from REGISTERUSER;