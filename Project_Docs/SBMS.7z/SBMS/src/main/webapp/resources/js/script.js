function login(){
  	var email= document.getElementById("email").value;
  	var password= document.getElementById("password").value;
	$.ajax({
			dataType: 'json',
       		headers: {
         				Accept:"application/json",
            			"Access-Control-Allow-Origin": "*"
       				},
  	  			url:"http://localhost:8080/SBMS/validatelogin",
  	  			type: "post",
  	  			data:  {email: email,password: password},
  	  			success: function(responseText)
  	  					{
							console.log(responseText);
							if(responseText.length!=0)
									{
										if(responseText.password==password)
											{
												if(responseText.role=="admin")
													{
														console.log("inside admin");
														$.redirect("/SBMS/admin", user={"id":responseText.uid, "fname": responseText.fname, "lname": responseText.lname, "email": responseText.email, "password":responseText.password, "role": responseText.role});
													}
												else if(responseText.role=="user")
													{
														console.log("inside user");
														$.redirect('/SBMS/user', user={"id":responseText.uid, "fname": responseText.fname, "lname": responseText.lname, "email": responseText.email, "password":responseText.password, "role": responseText.role});
													}
												else
													{
														console.log("inside error")
													  	window.location.replace("/SBMS/ErrorPage.jsp");
  													}
											}
										else
											{
												alert("Wrong password");
											}
									}
									else
									{
										alert("User does not exist, Please Register to continue..!");
									}		
								},
				error: function()
				{
					alert("Invalid Credentials!");
				}
			});
	 }



function register()
{
	console.log("inside register()");
	var fname=document.getElementById("fname").value;
	console.log(fname);
	var lname=document.getElementById("lname").value;
	var email=document.getElementById("email").value;
	var password=document.getElementById("password").value;
	var role="user";
	console.log(fname+" "+lname+""+ email+" "+ password+""+ role);
	$.ajax({
				dataType: 'json',
   				headers:
   				{
     				Accept:"application/json",
        			"Access-Control-Allow-Origin": "*"
   				},
	  			url:"http://localhost:8080/SBMS/registeruser",
	  			type: "post",
	  			async: true,
	  			data:  {fname: fname, lname: lname, email: email,password: password, role: role},
	  			success: function(responseText)
	  					{
	  						if(responseText==true)
	  						{
								alert("successfully registered please login to continue.......!");
								$.redirect("/SBMS/");
	  						}
	  					else
	  						{
	  						alert("email already exists please try again.....!");
	  						$.redirect("/SBMS/register");
	  						}
						}
		});
}