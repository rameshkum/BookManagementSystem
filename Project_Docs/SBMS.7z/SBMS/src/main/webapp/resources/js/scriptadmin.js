function adminViewFunction() {
 	  // Declare variables 
 	  var input, filter, table, tr, td, i;
 	  input = document.getElementById("myInput");
 	  filter = input.value.toUpperCase();
 	  table = document.getElementById("myTable");
 	  tr = table.getElementsByTagName("tr");

 	  // Loop through all table rows, and hide those who don't match the search query
 	  for (i = 0; i < tr.length; i++) {
 	    td = tr[i].getElementsByTagName("td")[1];
 	    if (td) {
 	      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
 	        tr[i].style.display = "";
 	      } else {
 	        tr[i].style.display = "none";
 	      }
 	    } 
 	  }
 	}

function bookListFunction() {
 // Declare variables 
 var input, filter, table, tr, td, i;
 input = document.getElementById("myInput");
 filter = input.value.toUpperCase();
 table = document.getElementById("myTable");
 tr = table.getElementsByTagName("tr");

 // Loop through all table rows, and hide those who don't match the search query
 for (i = 0; i < tr.length; i++) {
   td = tr[i].getElementsByTagName("td")[1];
   if (td) {
     if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
       tr[i].style.display = "";
     } else {
       tr[i].style.display = "none";
     }
   } 
 }
}

function AddBook()
{
	console.log("inside AddBook()");
	var bname=document.getElementById("bname").value;
	console.log(bname);
	var author=document.getElementById("author").value;
	var description=document.getElementById("description").value;
	var price=document.getElementById("price").value;
	console.log(bname+" "+author);
	$.ajax({
				dataType: 'json',
   				headers:
   				{
     				Accept:"application/json",
        			"Access-Control-Allow-Origin": "*"
   				},
	  			url:"http://localhost:8080/SBMS/admin/addbook",
	  			type: "post",
	  			async: true,
	  			data:  {bname: bname, author: author, description: description, price: price},
	  			success: function(responseText)
	  					{
	  						if(responseText==true)
	  						{
								alert("successfully added.......!");
								$.redirect("/SBMS/admin/blank");
	  						}
	  					else
	  						{
	  						alert("Book Already Exists.....!");
	  						$.redirect("/SBMS/admin/addbookpage");
	  						}
						}
		});
} 


function editBook()
{
	console.log("inside editBook()");
	var bid=document.getElementById("bid").value;
	var bname=document.getElementById("bname").value;
	console.log(bname);
	var author=document.getElementById("author").value;
	var description=document.getElementById("description").value;
	var price=document.getElementById("price").value;
	console.log(bname+" "+author);
	$.ajax({
				dataType: 'json',
   				headers:
   				{
     				Accept:"application/json",
        			"Access-Control-Allow-Origin": "*"
   				},
	  			url:"http://localhost:8080/SBMS/admin/updatebook",
	  			type: "post",
	  			data:  {bid:bid, bname: bname, author: author, description: description, price: price},
	  			success: function(responseText)
	  					{
	  						console.log(responseText);
	  						if(responseText==true)
	  							{
									alert("successfully editted.......!");
									$.redirect("/SBMS/admin/blank");
	  							}
	  						else
	  							{
	  								alert("Please Try Again.....!");
	  								$.redirect("/SBMS/admin/editbookpage");
	  							}
						},
				error: function()
				{
					alert("Error Occurred");
				}
		});
} 