function addReview()
	{
		 var uid=document.getElementById("uid").value;
		 console.log(uid);
		 var bid=document.getElementById("bid").value;
		var comments=document.getElementById("comments").value;
		console.log(comments);
		var rating=document.getElementById("rating").value; 
		var date=Date.prototype.toMysqlFormat();
	$.ajax({
			/* http://localhost:8080/SBMS/user/addreview/2?uid=2&bid
*/				url:"http://localhost:8080/SBMS/user/addreview",
				type: "post",
				data:  {comments:comments, rating:rating, date:date, bid:bid, uid:uid} ,
				 success: function(responseText)
				{
					if(responseText==true)
						{
							alert("Review successfully added");
							$.redirect("/SBMS/user/blank");
						}
					else
						{
							alert("Please Try Again");
							$.redirect("/SBMS/user/booklist");
						}	
				},
				error: function(){
					alert("Something went wrong");
				}
			});
		}
function twoDigits(d) {
		   	 if(0 <= d && d < 10) return "0" + d.toString();
		  	  if(-10 < d && d < 0) return "-0" + (-1*d).toString();
		  	  return d.toString();
			}
Date.prototype.toMysqlFormat = function() {
				var date=new Date();
			    return date.getUTCFullYear() + "-" + twoDigits(1 + date.getUTCMonth()) + "-" + twoDigits(date.getUTCDate()) + " " + twoDigits(date.getUTCHours()) + ":" + twoDigits(date.getUTCMinutes()) + ":" + twoDigits(date.getUTCSeconds());}
			console.log(Date.prototype.toMysqlFormat());
			console.log(typeof(Date.prototype.toMysqlFormat()));

function userBookList() {
 	 	  // Declare variables 
 	 	  var input, filter, table, tr, td, i;
 	 	  input = document.getElementById("myInput");
 	 	  filter = input.value.toUpperCase();
 	 	  table = document.getElementById("myTable");
 	 	  tr = table.getElementsByTagName("tr");

 	 	  // Loop through all table rows, and hide those who don't match the search query
 	 	  for (i = 0; i < tr.length; i++) {
 	 	    td = tr[i].getElementsByTagName("td")[1];
 	 	    if (td) {
 	 	      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
 	 	        tr[i].style.display = "";
 	 	      } else {
 	 	        tr[i].style.display = "none";
 	 	      }
 	 	    } 
 	 	  }
 	 	}